<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

$adminAuth = new AdminAuth();
if (!$adminAuth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = $_POST['current_password'];
    $new_username = $_POST['new_username'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // 验证当前密码
    if (!$adminAuth->verifyPassword($current_password)) {
        $error = '当前密码错误';
    } elseif (!empty($new_password) && $new_password !== $confirm_password) {
        $error = '新密码与确认密码不匹配';
    } else {
        // 更新用户名和密码
        $database_file = '../includes/database.php';
        $database_content = file_get_contents($database_file);

        // 更新用户名（如果提供了新用户名）
        if (!empty($new_username)) {
            $database_content = preg_replace(
                '/private\s+\$admin_username\s+=\s+\'[^\']*\';/', 
                "private \$admin_username = '$new_username';", 
                $database_content
            );
        }

        // 更新密码（如果提供了新密码）
        if (!empty($new_password)) {
            $database_content = preg_replace(
                '/private\s+\$admin_password\s+=\s+\'[^\']*\';/', 
                "private \$admin_password = '$new_password';", 
                $database_content
            );
        }

        file_put_contents($database_file, $database_content);

        // 如果更改了用户名，更新会话
        if (!empty($new_username)) {
            $_SESSION['admin_username'] = $new_username;
        }

        $success = '账号信息更新成功！';
    }
}

// 获取当前用户名
$reflection = new ReflectionClass($adminAuth);
$username_property = $reflection->getProperty('admin_username');
$username_property->setAccessible(true);
$current_username = $username_property->getValue($adminAuth);
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改管理员账号 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <!-- 樱花飘落效果 -->
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    
    <header>
        <h1>修改管理员账号</h1>
    </header>
    
    <main>
        <?php if (isset($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="login-container" style="max-width: 500px;">
            <h2>修改账号信息</h2>
            <form method="post">
                <div class="password-container">
                    <label for="current_password">当前密码:</label>
                    <input type="password" id="current_password" name="current_password" required>
                    <span class="toggle-password" onclick="togglePassword('current_password')">👁️</span>
                </div>
                
                <div>
                    <label for="new_username">新用户名 (留空则不修改):</label>
                    <input type="text" id="new_username" name="new_username" value="<?php echo htmlspecialchars($current_username); ?>">
                </div>
                
                <div class="password-container">
                    <label for="new_password">新密码 (留空则不修改):</label>
                    <input type="password" id="new_password" name="new_password">
                    <span class="toggle-password" onclick="togglePassword('new_password')">👁️</span>
                </div>
                
                <div class="password-container">
                    <label for="confirm_password">确认新密码:</label>
                    <input type="password" id="confirm_password" name="confirm_password">
                    <span class="toggle-password" onclick="togglePassword('confirm_password')">👁️</span>
                </div>
                
                <button type="submit">更新账号信息</button>
                <a href="dashboard.php" class="cancel-btn">返回仪表盘</a>
            </form>
        </div>
    </main>
    
    <!-- 右下角浮动导航按钮 -->
    <div class="floating-nav">
        <button class="nav-toggle" id="navToggle">
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
        </button>
        <div class="nav-menu" id="navMenu">
            <a href="../index.php" class="nav-link">首页</a>
            <a href="dashboard.php" class="nav-link">项目管理</a>
            <a href="add_project.php" class="nav-link">添加项目</a>
            <a href="beian.php" class="nav-link">备案信息</a>
            <a href="profile.php" class="nav-link">修改账号</a>
            <a href="logout.php" class="nav-link">退出登录</a>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <p>&copy; 2025 <?php echo SITE_NAME; ?>.</p>
            <?php 
            // 获取备案信息
            $beian_hao = defined('BEIAN_HAO') ? BEIAN_HAO : '';
            $beian_wangzhi = defined('BEIAN_WANGZHI') ? BEIAN_WANGZHI : '';
            $show_beian = defined('SHOW_BEIAN') ? SHOW_BEIAN : true;
            $show_author = defined('SHOW_AUTHOR') ? SHOW_AUTHOR : true;
            $show_user = defined('SHOW_USER') ? SHOW_USER : true;
            
            if ($show_beian && !empty($beian_hao)) {
                echo "<p>备案号: <a href='https://beian.miit.gov.cn/' target='_blank'>$beian_hao</a>";
                if (!empty($beian_wangzhi)) {
                    echo " | 网址: <a href='$beian_wangzhi' target='_blank'>$beian_wangzhi</a>";
                }
                echo "</p>";
            }
            
            if ($show_author) {
                echo "<p>作者: 赤源谷雨</p>";
            }
            
            if ($show_user) {
                echo "<p>使用者: " . (defined('SITE_USER') ? SITE_USER : '未知') . "</p>";
            }
            ?>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const navMenu = document.getElementById('navMenu');
            
            navToggle.addEventListener('click', function() {
                navMenu.classList.toggle('show');
            });
            
            // 点击菜单项后关闭菜单
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', () => {
                    navMenu.classList.remove('show');
                });
            });
        });
        
        function togglePassword(fieldId) {
            const passwordField = document.getElementById(fieldId);
            const isPassword = passwordField.type === 'password';
            passwordField.type = isPassword ? 'text' : 'password';
        }
    </script>
    
    <style>
        .cancel-btn {
            display: inline-block;
            margin-top: 10px;
            padding: 0.8rem 1.2rem;
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .cancel-btn:hover {
            background: rgba(255, 255, 255, 0.5);
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 182, 193, 0.4);
        }
    </style>
</body>
</html>