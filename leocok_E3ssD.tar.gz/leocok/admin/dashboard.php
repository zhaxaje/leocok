<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

$adminAuth = new AdminAuth();
if (!$adminAuth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 无需检查init.php文件，因为已在初始化时自动删除

$projectManager = new ProjectManager();
$projectManager->createProjectTable(); // 确保表存在

$projects = $projectManager->getAllProjects();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_project'])) {
        $title = $_POST['title'];
        $description = $_POST['description'];
        $link = $_POST['link'];
        
        if ($projectManager->addProject($title, $description, $link)) {
            $success = '项目添加成功！项目文件已创建在 x/ 目录下';
        } else {
            $error = '项目添加失败';
        }
    } elseif (isset($_POST['delete_project'])) {
        $id = $_POST['id'];
        if ($projectManager->deleteProject($id)) {
            $success = '项目删除成功！对应的文件夹也已清理';
        } else {
            $error = '项目删除失败';
        }
    }
    
    // 重新获取项目列表
    $projects = $projectManager->getAllProjects();
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员面板 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <!-- 樱花飘落效果 -->
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    
    <header>
        <h1>管理员面板</h1>
        <p>管理项目内容</p>
    </header>
    
    <nav style="display: none;">
        <a href="../index.php">返回首页</a>
        <a href="dashboard.php">项目管理</a>
        <a href="logout.php">退出登录</a>
    </nav>
    
    <main>
        <?php if (isset($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="admin-content">
            <div class="add-project-section">
                <h2>添加新项目</h2>
                <p>点击下面的按钮前往添加项目页面</p>
                <a href="add_project.php" class="add-project-btn">添加新项目</a>
            </div>
            
            <div class="projects-section">
                <h2>项目列表</h2>
                <?php if (empty($projects)): ?>
                    <p>暂无项目</p>
                <?php else: ?>
                    <div class="projects-list">
                        <?php foreach ($projects as $project): ?>
                            <div class="project-item">
                                <h3><?php echo htmlspecialchars($project['title']); ?></h3>
                                <p><?php echo htmlspecialchars($project['description']); ?></p>
                                <p><strong>链接:</strong> <a href="<?php echo htmlspecialchars($project['link']); ?>" target="_blank"><?php echo htmlspecialchars($project['link']); ?></a></p>
                                <p><small>发布时间: <?php echo date('Y-m-d H:i', strtotime($project['created_at'])); ?></small></p>
                                <div class="project-actions">
                                    <a href="edit_project.php?id=<?php echo $project['id']; ?>" class="edit-btn">编辑</a>
                                    <form method="post" style="display: inline;" onsubmit="return confirm('确定要删除这个项目吗?');">
                                        <input type="hidden" name="id" value="<?php echo $project['id']; ?>">
                                        <button type="submit" name="delete_project">删除</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    
    <!-- 右下角浮动导航按钮 -->
    <div class="floating-nav">
        <button class="nav-toggle" id="navToggle">
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
        </button>
        <div class="nav-menu" id="navMenu">
            <a href="../index.php" class="nav-link">首页</a>
            <a href="dashboard.php" class="nav-link">项目管理</a>
            <a href="add_project.php" class="nav-link">添加项目</a>
            <a href="beian.php" class="nav-link">备案信息</a>
            <a href="profile.php" class="nav-link">修改账号</a>
            <a href="logout.php" class="nav-link">退出登录</a>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <p>&copy; 2025 <?php echo SITE_NAME; ?>.</p>
            <?php 
            // 获取备案信息
            $beian_hao = defined('BEIAN_HAO') ? BEIAN_HAO : '';
            $beian_wangzhi = defined('BEIAN_WANGZHI') ? BEIAN_WANGZHI : '';
            $show_beian = defined('SHOW_BEIAN') ? SHOW_BEIAN : true;
            $show_author = defined('SHOW_AUTHOR') ? SHOW_AUTHOR : true;
            $show_user = defined('SHOW_USER') ? SHOW_USER : true;
            
            if ($show_beian && !empty($beian_hao)) {
                echo "<p>备案号: <a href='https://beian.miit.gov.cn/' target='_blank'>$beian_hao</a>";
                if (!empty($beian_wangzhi)) {
                    echo " | 网址: <a href='$beian_wangzhi' target='_blank'>$beian_wangzhi</a>";
                }
                echo "</p>";
            }
            
            if ($show_author) {
                echo "<p>作者: 赤源谷雨</p>";
            }
            
            if ($show_user) {
                echo "<p>使用者: " . (defined('SITE_USER') ? SITE_USER : '未知') . "</p>";
            }
            ?>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const navMenu = document.getElementById('navMenu');
            
            navToggle.addEventListener('click', function() {
                navMenu.classList.toggle('show');
            });
            
            // 点击菜单项后关闭菜单
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', () => {
                    navMenu.classList.remove('show');
                });
            });
            
            // 无需检查init.php文件，因为已在初始化时自动删除
        });
        
        function insertTag(tagName, placeholder, hasAttribute = false) {
            const textarea = document.getElementById('description');
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const selectedText = textarea.value.substring(start, end);
            
            let tagContent;
            if (hasAttribute) {
                // 对于彩色字体标签
                const attribute = prompt('请输入颜色代码 (例如: ff0000):', 'ff0000');
                if (attribute === null) return; // 用户取消操作
                tagContent = `<彩色字体=#${attribute}>${selectedText || placeholder}</彩色字体>`;
            } else {
                tagContent = `<${tagName}>${selectedText || placeholder}</${tagName}>`;
            }
            
            const textBefore = textarea.value.substring(0, start);
            const textAfter = textarea.value.substring(end);
            
            textarea.value = textBefore + tagContent + textAfter;
            textarea.focus();
            
            // 设置光标位置到插入内容之后
            const newCursorPos = start + tagContent.length;
            textarea.setSelectionRange(newCursorPos, newCursorPos);
        }
        
        // 无需检查init.php文件，因为已在初始化时自动删除
    </script>
    
    <style>
        .add-project-btn {
            display: inline-block;
            padding: 0.8rem 1.2rem;
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
            font-size: 1rem;
        }
        
        .add-project-btn:hover {
            background: rgba(255, 255, 255, 0.5);
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 182, 193, 0.4);
        }
        
        .editor-tools {
            margin: 10px 0;
        }
        
        .editor-tools h4 {
            margin-bottom: 5px;
            color: #fff;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        }
        
        .editor-tools button {
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 5px 10px;
            margin: 0 5px 5px 0;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .editor-tools button:hover {
            background: rgba(255, 255, 255, 0.5);
        }
    </style>
</body>
</html>