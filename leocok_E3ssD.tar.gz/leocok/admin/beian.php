<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

$adminAuth = new AdminAuth();
if (!$adminAuth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// 读取当前备案信息
$beian_file = '../includes/beian.php';
$beian_content = file_exists($beian_file) ? file_get_contents($beian_file) : '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $beian_hao = $_POST['beian_hao'] ?? '';
    $beian_wangzhi = $_POST['beian_wangzhi'] ?? '';
    $show_beian = isset($_POST['show_beian']) ? true : false;
    $show_author = isset($_POST['show_author']) ? true : false;
    $show_user = isset($_POST['show_user']) ? true : false;
    $site_user = $_POST['site_user'] ?? '';

    // 创建备案信息配置内容
    $new_content = "<?php\n";
    $new_content .= "// 备案信息配置文件\n\n";
    $new_content .= "// 备案号\n";
    $new_content .= "if (!defined('BEIAN_HAO')) {\n";
    $new_content .= "    define('BEIAN_HAO', '" . addslashes($beian_hao) . "');\n";
    $new_content .= "}\n\n";
    $new_content .= "// 备案网址\n";
    $new_content .= "if (!defined('BEIAN_WANGZHI')) {\n";
    $new_content .= "    define('BEIAN_WANGZHI', '" . addslashes($beian_wangzhi) . "');\n";
    $new_content .= "}\n\n";
    $new_content .= "// 是否显示备案信息\n";
    $new_content .= "if (!defined('SHOW_BEIAN')) {\n";
    $new_content .= "    define('SHOW_BEIAN', " . ($show_beian ? 'true' : 'false') . ");\n";
    $new_content .= "}\n\n";
    $new_content .= "// 是否显示作者信息\n";
    $new_content .= "if (!defined('SHOW_AUTHOR')) {\n";
    $new_content .= "    define('SHOW_AUTHOR', " . ($show_author ? 'true' : 'false') . ");\n";
    $new_content .= "}\n\n";
    $new_content .= "// 是否显示使用者信息\n";
    $new_content .= "if (!defined('SHOW_USER')) {\n";
    $new_content .= "    define('SHOW_USER', " . ($show_user ? 'true' : 'false') . ");\n";
    $new_content .= "}\n\n";
    $new_content .= "// 使用者名称\n";
    $new_content .= "if (!defined('SITE_USER')) {\n";
    $new_content .= "    define('SITE_USER', '" . addslashes($site_user) . "');\n";
    $new_content .= "}\n";
    $new_content .= "?>\n";

    // 写入备案信息配置文件
    if (file_put_contents($beian_file, $new_content)) {
        $success = '备案信息更新成功！';
        // 重新加载页面以获取新值
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $error = '备案信息更新失败，请检查文件权限';
    }
}

// 重新读取备案信息
include $beian_file;
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>备案信息管理 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <!-- 樱花飘落效果 -->
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    
    <header>
        <h1>备案信息管理</h1>
    </header>
    
    <main>
        <?php if (isset($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="login-container" style="max-width: 600px;">
            <h2>配置网站备案信息</h2>
            <form method="post">
                <div>
                    <label for="beian_hao">备案号:</label>
                    <input type="text" id="beian_hao" name="beian_hao" value="<?php echo htmlspecialchars(BEIAN_HAO); ?>" placeholder="例如：京ICP备xxxxxxxx号">
                </div>
                
                <div>
                    <label for="beian_wangzhi">备案网址:</label>
                    <input type="text" id="beian_wangzhi" name="beian_wangzhi" value="<?php echo htmlspecialchars(BEIAN_WANGZHI); ?>" placeholder="例如：www.beian.gov.cn">
                </div>
                
                <div>
                    <label for="site_user">使用者名称:</label>
                    <input type="text" id="site_user" name="site_user" value="<?php echo htmlspecialchars(SITE_USER); ?>" placeholder="您的名称或组织名称">
                </div>
                
                <div class="checkbox-group">
                    <label>
                        <input type="checkbox" name="show_beian" value="1" <?php echo SHOW_BEIAN ? 'checked' : ''; ?>> 显示备案信息
                    </label>
                </div>
                
                <div class="checkbox-group">
                    <label>
                        <input type="checkbox" name="show_author" value="1" <?php echo SHOW_AUTHOR ? 'checked' : ''; ?>> 显示作者信息 (不可关闭)
                    </label>
                </div>
                
                <div class="checkbox-group">
                    <label>
                        <input type="checkbox" name="show_user" value="1" <?php echo SHOW_USER ? 'checked' : ''; ?>> 显示使用者信息
                    </label>
                </div>
                
                <button type="submit">保存备案信息</button>
                <a href="dashboard.php" class="cancel-btn">返回仪表盘</a>
            </form>
        </div>
    </main>
    
    <!-- 右下角浮动导航按钮 -->
    <div class="floating-nav">
        <button class="nav-toggle" id="navToggle">
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
        </button>
        <div class="nav-menu" id="navMenu">
            <a href="../index.php" class="nav-link">首页</a>
            <a href="dashboard.php" class="nav-link">项目管理</a>
            <a href="add_project.php" class="nav-link">添加项目</a>
            <a href="profile.php" class="nav-link">修改账号</a>
            <a href="beian.php" class="nav-link">备案信息</a>
            <a href="logout.php" class="nav-link">退出登录</a>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <p>&copy; 2025 <?php echo SITE_NAME; ?>.</p>
            <?php 
            if (SHOW_BEIAN && !empty(BEIAN_HAO)) {
                echo "<p>备案号: <a href='https://beian.miit.gov.cn/' target='_blank'>" . htmlspecialchars(BEIAN_HAO) . "</a>";
                if (!empty(BEIAN_WANGZHI)) {
                    echo " | 网址: <a href='http://" . htmlspecialchars(BEIAN_WANGZHI) . "' target='_blank'>" . htmlspecialchars(BEIAN_WANGZHI) . "</a>";
                }
                echo "</p>";
            }
            
            if (SHOW_AUTHOR) {
                echo "<p>作者: 赤源谷雨</p>";
            }
            
            if (SHOW_USER) {
                echo "<p>使用者: " . htmlspecialchars(SITE_USER ?: '未知') . "</p>";
            }
            ?>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const navMenu = document.getElementById('navMenu');
            
            navToggle.addEventListener('click', function() {
                navMenu.classList.toggle('show');
            });
            
            // 点击菜单项后关闭菜单
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', () => {
                    navMenu.classList.remove('show');
                });
            });
        });
    </script>
    
    <style>
        .cancel-btn {
            display: inline-block;
            margin-top: 10px;
            padding: 0.8rem 1.2rem;
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .cancel-btn:hover {
            background: rgba(255, 255, 255, 0.5);
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 182, 193, 0.4);
        }
        
        .checkbox-group {
            margin: 10px 0;
        }
        
        .checkbox-group label {
            display: flex;
            align-items: center;
            color: #fff;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        }
        
        .checkbox-group input[type="checkbox"] {
            margin-right: 8px;
            transform: scale(1.2);
        }
    </style>
</body>
</html>