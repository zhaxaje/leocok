<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    $adminAuth = new AdminAuth();
    if ($adminAuth->login($username, $password)) {
        // $_SESSION['admin_logged_in'] = true; 这在AdminAuth::login方法中已经设置
        header('Location: dashboard.php');
        exit;
    } else {
        $error = '用户名或密码错误';
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员登录 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <!-- 樱花飘落效果 -->
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    
    <div class="login-container">
        <h2>管理员登录</h2>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="post">
            <div>
                <label for="username">用户名:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="password-container">
                <label for="password">密码:</label>
                <input type="password" id="password" name="password" required>
                <span class="toggle-password" onclick="togglePassword('password')">👁️</span>
            </div>
            <button type="submit">登录</button>
        </form>
    </div>
    
    <!-- 右下角浮动导航按钮 -->
    <div class="floating-nav">
        <button class="nav-toggle" id="navToggle">
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
        </button>
        <div class="nav-menu" id="navMenu">
            <a href="../index.php" class="nav-link">首页</a>
            <a href="dashboard.php" class="nav-link">项目管理</a>
            <a href="add_project.php" class="nav-link">添加项目</a>
            <a href="login.php" class="nav-link">登录</a>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const navMenu = document.getElementById('navMenu');
            
            navToggle.addEventListener('click', function() {
                navMenu.classList.toggle('show');
            });
            
            // 点击菜单项后关闭菜单
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', () => {
                    navMenu.classList.remove('show');
                });
            });
        });
        
        function togglePassword(fieldId) {
            const passwordField = document.getElementById(fieldId);
            const isPassword = passwordField.type === 'password';
            passwordField.type = isPassword ? 'text' : 'password';
        }
    </script>
</body>
</html>