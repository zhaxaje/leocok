<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/database.php';

$adminAuth = new AdminAuth();
if (!$adminAuth->isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$projectManager = new ProjectManager();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $link = $_POST['link'];
    
    if ($projectManager->addProject($title, $description, $link)) {
        $success = '项目添加成功！项目文件已创建在 x/ 目录下';
    } else {
        $error = '项目添加失败';
    }
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>添加项目 - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <!-- 樱花飘落效果 -->
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    
    <header>
        <h1>添加新项目</h1>
    </header>
    
    <main>
        <?php if (isset($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="login-container" style="max-width: 600px;">
            <form method="post">
                <div>
                    <label for="title">项目标题:</label>
                    <input type="text" id="title" name="title" required>
                </div>
                <div class="editor-tools">
                    <h4>格式工具:</h4>
                    <button type="button" onclick="insertTag('链接', '输入网址')">插入链接</button>
                    <button type="button" onclick="insertTag('显示图片', '图片链接')">插入图片</button>
                    <button type="button" onclick="insertTag('彩色字体=#ff0000', '文字', true)">彩色字体</button>
                </div>
                <div>
                    <label for="description">项目描述:</label>
                    <textarea id="description" name="description" rows="6" placeholder="可以使用以下格式：&#10;<链接>https://example.com</链接> - 创建超链接&#10;<显示图片>image.jpg</显示图片> - 显示图片&#10;<彩色字体=#ff0000>文字</彩色字体> - 彩色字体"></textarea>
                </div>
                <div>
                    <label for="link">项目链接:</label>
                    <input type="url" id="link" name="link" required placeholder="https://example.com">
                </div>
                <button type="submit">添加项目</button>
                <a href="dashboard.php" class="cancel-btn">返回仪表盘</a>
            </form>
        </div>
    </main>
    
    <!-- 右下角浮动导航按钮 -->
    <div class="floating-nav">
        <button class="nav-toggle" id="navToggle">
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
        </button>
        <div class="nav-menu" id="navMenu">
            <a href="../index.php" class="nav-link">首页</a>
            <a href="dashboard.php" class="nav-link">项目管理</a>
            <a href="add_project.php" class="nav-link">添加项目</a>
            <a href="beian.php" class="nav-link">备案信息</a>
            <a href="profile.php" class="nav-link">修改账号</a>
            <a href="logout.php" class="nav-link">退出登录</a>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <p>&copy; 2025 <?php echo SITE_NAME; ?>.</p>
            <?php 
            // 获取备案信息
            $beian_hao = defined('BEIAN_HAO') ? BEIAN_HAO : '';
            $beian_wangzhi = defined('BEIAN_WANGZHI') ? BEIAN_WANGZHI : '';
            $show_beian = defined('SHOW_BEIAN') ? SHOW_BEIAN : true;
            $show_author = defined('SHOW_AUTHOR') ? SHOW_AUTHOR : true;
            $show_user = defined('SHOW_USER') ? SHOW_USER : true;
            
            if ($show_beian && !empty($beian_hao)) {
                echo "<p>备案号: <a href='https://beian.miit.gov.cn/' target='_blank'>$beian_hao</a>";
                if (!empty($beian_wangzhi)) {
                    echo " | 网址: <a href='$beian_wangzhi' target='_blank'>$beian_wangzhi</a>";
                }
                echo "</p>";
            }
            
            if ($show_author) {
                echo "<p>作者: 赤源谷雨</p>";
            }
            
            if ($show_user) {
                echo "<p>使用者: " . (defined('SITE_USER') ? SITE_USER : '未知') . "</p>";
            }
            ?>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const navMenu = document.getElementById('navMenu');
            
            navToggle.addEventListener('click', function() {
                navMenu.classList.toggle('show');
            });
            
            // 点击菜单项后关闭菜单
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', () => {
                    navMenu.classList.remove('show');
                });
            });
        });
        
        function insertTag(tagName, placeholder, hasAttribute = false) {
            const textarea = document.getElementById('description');
            const start = textarea.selectionStart;
            const end = textarea.selectionEnd;
            const selectedText = textarea.value.substring(start, end);
            
            let tagContent;
            if (hasAttribute) {
                // 对于彩色字体标签
                const attribute = prompt('请输入颜色代码 (例如: ff0000):', 'ff0000');
                if (attribute === null) return; // 用户取消操作
                tagContent = `<彩色字体=#${attribute}>${selectedText || placeholder}</彩色字体>`;
            } else {
                tagContent = `<${tagName}>${selectedText || placeholder}</${tagName}>`;
            }
            
            const textBefore = textarea.value.substring(0, start);
            const textAfter = textarea.value.substring(end);
            
            textarea.value = textBefore + tagContent + textAfter;
            textarea.focus();
            
            // 设置光标位置到插入内容之后
            const newCursorPos = start + tagContent.length;
            textarea.setSelectionRange(newCursorPos, newCursorPos);
        }
    </script>
    
    <style>
        .cancel-btn {
            display: inline-block;
            margin-top: 10px;
            padding: 0.8rem 1.2rem;
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
            text-decoration: none;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .cancel-btn:hover {
            background: rgba(255, 255, 255, 0.5);
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(255, 182, 193, 0.4);
        }
        
        .editor-tools {
            margin: 10px 0;
        }
        
        .editor-tools h4 {
            margin-bottom: 5px;
            color: #fff;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        }
        
        .editor-tools button {
            background: rgba(255, 255, 255, 0.3);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 5px 10px;
            margin: 0 5px 5px 0;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .editor-tools button:hover {
            background: rgba(255, 255, 255, 0.5);
        }
    </style>
</body>
</html>