<?php
session_start();

// 确保用户已登录且是管理员
require_once '../includes/config.php';
require_once '../includes/database.php';

$adminAuth = new AdminAuth();
if (!$adminAuth->isLoggedIn()) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => '未授权访问']);
    exit;
}

// 确保请求是POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => '无效的请求方法']);
    exit;
}

$action = $_POST['action'] ?? '';

// 获取目标文件路径
$initPath = __DIR__ . '/../init.php';

// 验证init.php文件是否存在
if (!file_exists($initPath)) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'init.php文件不存在']);
    exit;
}

// 处理删除或重命名操作
if ($action === 'delete') {
    // 尝试删除文件
    if (unlink($initPath)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => '文件删除成功']);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => '无法删除文件，可能没有权限']);
    }
} elseif ($action === 'rename') {
    // 获取新文件名
    $newName = $_POST['new_name'] ?? 'init_backup.php';
    
    // 验证新文件名（防止路径遍历攻击）
    $newName = basename($newName); // 只取文件名部分，去掉路径
    $newPath = __DIR__ . '/../' . $newName;
    
    // 确保新文件名以.php结尾
    if (!preg_match('/\.php$/', $newName)) {
        $newName .= '.php';
        $newPath = __DIR__ . '/../' . $newName;
    }
    
    // 检查新文件名是否已存在
    if (file_exists($newPath)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => '目标文件已存在，请选择其他文件名']);
        exit;
    }
    
    // 尝试重命名文件
    if (rename($initPath, $newPath)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'message' => "文件已重命名为$newName"]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => '无法重命名文件，可能没有权限']);
    }
} else {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => '无效的操作类型']);
}
?>