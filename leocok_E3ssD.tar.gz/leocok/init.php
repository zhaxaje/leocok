<?php
// 检查是否在配置数据库阶段
if (isset($_POST['step']) && $_POST['step'] == 'database') {
    // 获取数据库连接信息
    $db_host = $_POST['db_host'] ?? 'localhost';
    $db_user = $_POST['db_user'] ?? 'root';
    $db_pass = $_POST['db_pass'] ?? '';
    $db_name = $_POST['db_name'] ?? 'leocok_blog';
    
    // 尝试连接数据库
    try {
        // 确保使用密码连接
        $pdo = new PDO("mysql:host=$db_host", $db_user, $db_pass);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        die("数据库连接失败: " . $e->getMessage() . "<br>请检查用户名和密码是否正确。<br><a href='init.php' style='color: #ff69b4;'>返回重新配置</a>");
    }
    
    // 创建数据库（如果不存在）
    try {
        $pdo->exec("CREATE DATABASE IF NOT EXISTS $db_name CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE $db_name");
    } catch (PDOException $e) {
        die("数据库创建失败: " . $e->getMessage() . "<br><a href='init.php' style='color: #ff69b4;'>返回重新配置</a>");
    }
    
    // 创建配置文件内容
    $config_content = "<?php\n";
    $config_content .= "// 数据库配置\n";
    $config_content .= "define('DB_HOST', '$db_host');\n";
    $config_content .= "define('DB_USER', '$db_user');\n";
    $config_content .= "define('DB_PASS', '$db_pass');\n";
    $config_content .= "define('DB_NAME', '$db_name');\n\n";
    $config_content .= "// 创建数据库连接\n";
    $config_content .= "function getConnection() {\n";
    $config_content .= "    try {\n";
    $config_content .= "        \$pdo = new PDO(\"mysql:host=\" . DB_HOST . \";dbname=\" . DB_NAME, DB_USER, DB_PASS);\n";
    $config_content .= "        \$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);\n";
    $config_content .= "        return \$pdo;\n";
    $config_content .= "    } catch(PDOException \$e) {\n";
    $config_content .= "        die(\"连接失败: \" . \$e->getMessage());\n";
    $config_content .= "    }\n";
    $config_content .= "}\n\n";
    $config_content .= "// 站点基本信息\n";
    $config_content .= "define('SITE_URL', 'http://www.leocok.cn');\n";
    $config_content .= "define('SITE_NAME', 'leocok博客');\n";
    $config_content .= "?>\n";
    
    // 尝试写入配置文件
    $config_file = 'includes/config.php';
    
    // 检查目录是否可写
    if (!is_writable('includes/')) {
        die("includes/ 目录没有写入权限<br>请在服务器上执行以下命令设置权限:<br>chmod 755 includes/<br>chmod 644 includes/config.php<br><a href='init.php' style='color: #ff69b4;'>返回重新配置</a>");
    }
    
    // 检查文件是否可写（如果文件存在）
    if (file_exists($config_file) && !is_writable($config_file)) {
        die("includes/config.php 文件没有写入权限<br>请在服务器上执行以下命令设置权限:<br>chmod 644 includes/config.php<br><a href='init.php' style='color: #ff69b4;'>返回重新配置</a>");
    }
    
    if (file_put_contents($config_file, $config_content) === false) {
        die("无法写入配置文件<br>请检查服务器权限设置或联系管理员<br><a href='init.php' style='color: #ff69b4;'>返回重新配置</a>");
    }
    
    // 包含配置文件和数据库文件
    require_once 'includes/config.php';
    require_once 'includes/database.php';
    
    $projectManager = new ProjectManager();
    $projectManager->createProjectTable();
    
    // 数据库配置完成，显示下一步按钮
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>系统初始化 - <?php echo $db_name; ?></title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <!-- 樱花飘落效果 -->
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        
        <div class="login-container">
            <h2>数据库配置成功</h2>
            <p>数据库 "<?php echo htmlspecialchars($db_name); ?>" 创建成功！</p>
            <p>现在您可以配置管理员账号信息。</p>
            <form method="post" action="init.php">
                <input type="hidden" name="step" value="admin">
                <input type="hidden" name="db_host" value="<?php echo htmlspecialchars($db_host); ?>">
                <input type="hidden" name="db_user" value="<?php echo htmlspecialchars($db_user); ?>">
                <input type="hidden" name="db_pass" value="<?php echo htmlspecialchars($db_pass); ?>">
                <input type="hidden" name="db_name" value="<?php echo htmlspecialchars($db_name); ?>">
                
                <div>
                    <label for="admin_username">管理员用户名:</label>
                    <input type="text" id="admin_username" name="admin_username" required>
                </div>
                <div class="password-container">
                    <label for="admin_password">管理员密码:</label>
                    <input type="password" id="admin_password" name="admin_password" required autocomplete="new-password">
                    <span class="toggle-password" onclick="togglePassword('admin_password')">👁️</span>
                </div>
                <div class="password-container">
                    <label for="admin_password_confirm">确认管理员密码:</label>
                    <input type="password" id="admin_password_confirm" name="admin_password_confirm" required autocomplete="new-password">
                    <span class="toggle-password" onclick="togglePassword('admin_password_confirm')">👁️</span>
                </div>
                <button type="submit">完成初始化</button>
            </form>
        </div>
        <script>
            function togglePassword(fieldId) {
                const passwordField = document.getElementById(fieldId);
                const isPassword = passwordField.type === 'password';
                passwordField.type = isPassword ? 'text' : 'password';
            }
        </script>
    </body>
    </html>
    <?php
} 
// 检查是否在配置管理员阶段
elseif (isset($_POST['step']) && $_POST['step'] == 'admin') {
    // 获取数据库信息
    $db_host = $_POST['db_host'];
    $db_user = $_POST['db_user'];
    $db_pass = $_POST['db_pass'];
    $db_name = $_POST['db_name'];
    
    // 获取管理员信息
    $username = $_POST['admin_username'];
    $password = $_POST['admin_password'];
    $confirm_password = $_POST['admin_password_confirm'];
    
    // 验证密码确认
    if ($password !== $confirm_password) {
        die("密码确认不匹配，请返回重试。<br><a href='init.php' style='color: #ff69b4;'>返回重新配置</a>");
    }
    
    // 检查database.php文件是否可写
    if (!is_writable('includes/database.php')) {
        die("includes/database.php 文件没有写入权限，请设置文件权限为可写<br><a href='init.php' style='color: #ff69b4;'>返回重新配置</a>");
    }
    
    // 更新数据库文件中的管理员凭据（直接替换明文）
    $database_content = file_get_contents('includes/database.php');
    
    // 更新用户名和密码
    $database_content = preg_replace(
        '/private\s+\$admin_username\s+=\s+\'[^\']*\';/', 
        "private \$admin_username = '$username';", 
        $database_content
    );
    
    $database_content = preg_replace(
        '/private\s+\$admin_password\s+=\s+\'[^\']*\';/', 
        "private \$admin_password = '$password';", 
        $database_content
    );
    
    if (!file_put_contents('includes/database.php', $database_content)) {
        die("无法写入数据库文件，请确保 includes/database.php 文件具有写入权限，请确保目录权限为775以上<br><a href='init.php' style='color: #ff69b4;'>返回重新配置</a>");
    }
    
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>系统初始化 - 完成</title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <!-- 樱花飘落效果 -->
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        
        <div class="login-container">
            <h2>配置完成！</h2>
            <p>数据库和表创建成功，管理员账户已设置。</p>
            <p>现在您可以 <a href='admin/login.php' style='color: #ff69b4;'>登录管理员面板</a></p>
            <p>为安全起见，请删除 init.php 文件。</p>
        </div>
    </body>
    </html>
    <?php
} 
// 显示数据库配置表单
else {
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>系统初始化</title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <!-- 樱花飘落效果 -->
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        <div class="sakura"></div>
        
        <div class="login-container">
            <h2>系统初始化设置</h2>
            <p>请配置数据库连接信息</p>
            <form method="post">
                <input type="hidden" name="step" value="database">
                <div>
                    <label for="db_host">数据库主机:</label>
                    <input type="text" id="db_host" name="db_host" value="localhost" required>
                </div>
                <div>
                    <label for="db_user">数据库用户名:</label>
                    <input type="text" id="db_user" name="db_user" value="root" required>
                </div>
                <div class="password-container">
                    <label for="db_pass">数据库密码:</label>
                    <input type="password" id="db_pass" name="db_pass" autocomplete="new-password">
                    <span class="toggle-password" onclick="togglePassword('db_pass')">👁️</span>
                </div>
                <div>
                    <label for="db_name">数据库名称:</label>
                    <input type="text" id="db_name" name="db_name" value="leocok_blog" required>
                </div>
                <button type="submit">配置数据库</button>
            </form>
        </div>
        <script>
            function togglePassword(fieldId) {
                const passwordField = document.getElementById(fieldId);
                const isPassword = passwordField.type === 'password';
                passwordField.type = isPassword ? 'text' : 'password';
            }
        </script>
    </body>
    </html>
    <?php
}
?>