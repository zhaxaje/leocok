<?php
// 数据库配置 - 这些值将在初始化时被替换
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'leocok_blog');

// 创建数据库连接
function getConnection() {
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch(PDOException $e) {
        die("连接失败: " . $e->getMessage());
    }
}

// 站点基本信息
define('SITE_URL', 'http://www.leocok.cn');
define('SITE_NAME', 'leocok博客');

// 包含备案信息配置
if (file_exists('includes/beian.php')) {
    require_once 'includes/beian.php';
} else {
    // 默认备案信息配置
    if (!defined('BEIAN_HAO')) {
        define('BEIAN_HAO', '');
    }
    
    if (!defined('BEIAN_WANGZHI')) {
        define('BEIAN_WANGZHI', '');
    }
    
    if (!defined('SHOW_BEIAN')) {
        define('SHOW_BEIAN', true);
    }
    
    if (!defined('SHOW_AUTHOR')) {
        define('SHOW_AUTHOR', true);
    }
    
    if (!defined('SHOW_USER')) {
        define('SHOW_USER', true);
    }
    
    if (!defined('SITE_USER')) {
        define('SITE_USER', '');
    }
}
?>