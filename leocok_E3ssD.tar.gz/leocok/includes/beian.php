<?php
// 备案信息配置文件

// 备案号
if (!defined('BEIAN_HAO')) {
    define('BEIAN_HAO', '');
}

// 备案网址
if (!defined('BEIAN_WANGZHI')) {
    define('BEIAN_WANGZHI', '');
}

// 是否显示备案信息
if (!defined('SHOW_BEIAN')) {
    define('SHOW_BEIAN', true);
}

// 是否显示作者信息
if (!defined('SHOW_AUTHOR')) {
    define('SHOW_AUTHOR', true);
}

// 是否显示使用者信息
if (!defined('SHOW_USER')) {
    define('SHOW_USER', true);
}

// 使用者名称
if (!defined('SITE_USER')) {
    define('SITE_USER', '');
}
?>