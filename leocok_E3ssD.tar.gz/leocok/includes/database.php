<?php
require_once 'config.php';

class ProjectManager {
    private $pdo;
    
    public function __construct() {
        $this->pdo = getConnection();
    }
    
    // 创建项目表
    public function createProjectTable() {
        $sql = "CREATE TABLE IF NOT EXISTS projects (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            link VARCHAR(500) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        
        $this->pdo->exec($sql);
    }
    
    // 添加项目
    public function addProject($title, $description, $link) {
        // 获取下一个可用的数字ID
        $nextId = $this->getNextAvailableId();
        
        // 创建项目HTML文件
        $projectFile = __DIR__ . '/../x/' . $nextId . '.html';
        
        // 处理特殊标签
        $processedDescription = $this->processSpecialTags($description);
        
        // 生成HTML内容
        $htmlContent = "<!DOCTYPE html>\n";
        $htmlContent .= "<html lang='zh-CN'>\n";
        $htmlContent .= "<head>\n";
        $htmlContent .= "    <meta charset='UTF-8'>\n";
        $htmlContent .= "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>\n";
        $htmlContent .= "    <title>$title - 项目详情</title>\n";
        $htmlContent .= "    <style>\n";
        $htmlContent .= "        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background: linear-gradient(135deg, #fbc2eb 0%, #a6c1ee 100%); }\n";
        $htmlContent .= "        .project-container { background: rgba(255, 255, 255, 0.8); padding: 30px; border-radius: 15px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1); backdrop-filter: blur(5px); }\n";
        $htmlContent .= "        .project-title { color: #ff69b4; border-bottom: 2px solid #ff69b4; padding-bottom: 10px; }\n";
        $htmlContent .= "        .project-link { display: inline-block; background: #ff69b4; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 15px; }\n";
        $htmlContent .= "        .back-link { display: inline-block; margin-top: 15px; color: #ff69b4; text-decoration: none; }\n";
        $htmlContent .= "        .image-container { text-align: center; margin: 15px 0; }\n";
        $htmlContent .= "        .image-container img { max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }\n";
        $htmlContent .= "    </style>\n";
        $htmlContent .= "</head>\n";
        $htmlContent .= "<body>\n";
        $htmlContent .= "    <div class='project-container'>\n";
        $htmlContent .= "        <h1 class='project-title'>$title</h1>\n";
        $htmlContent .= "        <div class='project-description'>\n";
        $htmlContent .= "            <h3>项目描述:</h3>\n";
        $htmlContent .= "            <div>" . $processedDescription . "</div>\n";
        $htmlContent .= "        </div>\n";
        $htmlContent .= "        <div class='project-link-container'>\n";
        $htmlContent .= "            <a href='$link' target='_blank' class='project-link'>访问项目</a>\n";
        $htmlContent .= "        </div>\n";
        $htmlContent .= "        <div class='project-info'>\n";
        $htmlContent .= "            <p><strong>项目链接:</strong> <a href='$link' target='_blank'>$link</a></p>\n";
        $htmlContent .= "        </div>\n";
        $htmlContent .= "        <a href='../index.php' class='back-link'>← 返回项目列表</a>\n";
        $htmlContent .= "    </div>\n";
        $htmlContent .= "</body>\n";
        $htmlContent .= "</html>\n";
        
        // 写入HTML文件
        file_put_contents($projectFile, $htmlContent);
        
        $sql = "INSERT INTO projects (title, description, link) VALUES (?, ?, ?)";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$title, $description, $link]);
    }
    
    // 获取下一个可用ID
    private function getNextAvailableId() {
        $sql = "SELECT id FROM projects ORDER BY id DESC LIMIT 1";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        $lastRow = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $nextId = 1;
        if ($lastRow) {
            $nextId = $lastRow['id'] + 1;
        }
        
        // 确保ID在1-999999范围内
        if ($nextId > 999999) {
            $nextId = 1; // 如果超过范围则从头开始（实际应用中应该不重复使用已删除的ID）
        }
        
        return $nextId;
    }
    
    // 获取所有项目
    public function getAllProjects() {
        $sql = "SELECT * FROM projects ORDER BY created_at DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // 删除项目
    public function deleteProject($id) {
        // 同时删除对应的项目HTML文件
        $projectFile = __DIR__ . '/../x/' . $id . '.html';
        if (file_exists($projectFile)) {
            unlink($projectFile);
        }
        
        $sql = "DELETE FROM projects WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$id]);
    }
    
    // 更新项目
    public function updateProject($id, $title, $description, $link) {
        // 更新对应的项目HTML文件
        $projectFile = __DIR__ . '/../x/' . $id . '.html';
        if (file_exists($projectFile)) {
            // 处理特殊标签
            $processedDescription = $this->processSpecialTags($description);
            
            // 生成新的HTML内容
            $htmlContent = "<!DOCTYPE html>\n";
            $htmlContent .= "<html lang='zh-CN'>\n";
            $htmlContent .= "<head>\n";
            $htmlContent .= "    <meta charset='UTF-8'>\n";
            $htmlContent .= "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>\n";
            $htmlContent .= "    <title>$title - 项目详情</title>\n";
            $htmlContent .= "    <style>\n";
            $htmlContent .= "        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; background: linear-gradient(135deg, #fbc2eb 0%, #a6c1ee 100%); }\n";
            $htmlContent .= "        .project-container { background: rgba(255, 255, 255, 0.8); padding: 30px; border-radius: 15px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1); backdrop-filter: blur(5px); }\n";
            $htmlContent .= "        .project-title { color: #ff69b4; border-bottom: 2px solid #ff69b4; padding-bottom: 10px; }\n";
            $htmlContent .= "        .project-link { display: inline-block; background: #ff69b4; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 15px; }\n";
            $htmlContent .= "        .back-link { display: inline-block; margin-top: 15px; color: #ff69b4; text-decoration: none; }\n";
            $htmlContent .= "        .image-container { text-align: center; margin: 15px 0; }\n";
            $htmlContent .= "        .image-container img { max-width: 100%; height: auto; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }\n";
            $htmlContent .= "    </style>\n";
            $htmlContent .= "</head>\n";
            $htmlContent .= "<body>\n";
            $htmlContent .= "    <div class='project-container'>\n";
            $htmlContent .= "        <h1 class='project-title'>$title</h1>\n";
            $htmlContent .= "        <div class='project-description'>\n";
            $htmlContent .= "            <h3>项目描述:</h3>\n";
            $htmlContent .= "            <div>" . $processedDescription . "</div>\n";
            $htmlContent .= "        </div>\n";
            $htmlContent .= "        <div class='project-link-container'>\n";
            $htmlContent .= "            <a href='$link' target='_blank' class='project-link'>访问项目</a>\n";
            $htmlContent .= "        </div>\n";
            $htmlContent .= "        <div class='project-info'>\n";
            $htmlContent .= "            <p><strong>项目链接:</strong> <a href='$link' target='_blank'>$link</a></p>\n";
            $htmlContent .= "        </div>\n";
            $htmlContent .= "        <a href='../index.php' class='back-link'>← 返回项目列表</a>\n";
            $htmlContent .= "    </div>\n";
            $htmlContent .= "</body>\n";
            $htmlContent .= "</html>\n";
            
            file_put_contents($projectFile, $htmlContent);
        }
        
        $sql = "UPDATE projects SET title = ?, description = ?, link = ? WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        return $stmt->execute([$title, $description, $link, $id]);
    }
    
    // 获取单个项目
    public function getProjectById($id) {
        $sql = "SELECT * FROM projects WHERE id = ?";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    // 处理特殊标签
    private function processSpecialTags($content) {
        // 处理 <链接>输入网址</链接> 标签
        $content = preg_replace_callback(
            '/<链接>(.*?)<\/链接>/',
            function($matches) {
                $url = trim($matches[1]);
                return "<a href='$url' target='_blank' style='color: #ff69b4; text-decoration: underline;'>$url</a>";
            },
            $content
        );
        
        // 处理 <显示图片>图片链接</显示图片> 标签
        $content = preg_replace_callback(
            '/<显示图片>(.*?)<\/显示图片>/',
            function($matches) {
                $imgSrc = trim($matches[1]);
                return "<div class='image-container'><img src='$imgSrc' alt='项目图片'></div>";
            },
            $content
        );
        
        // 处理 <彩色字体=(#[a-fA-F0-9]{3,6}|[a-zA-Z]+)>文字</彩色字体> 标签
        $content = preg_replace_callback(
            '/<彩色字体=(.*?)>(.*?)<\/彩色字体>/',
            function($matches) {
                $color = $matches[1];
                $text = $matches[2];
                // 如果颜色不是十六进制格式，在前面添加 #
                if (!preg_match('/^#([a-fA-F0-9]{3}|[a-fA-F0-9]{6})$/', $color) && !preg_match('/^[a-zA-Z]+$/', $color)) {
                    $color = '#' . $color;
                }
                return "<span style='color: $color;'>$text</span>";
            },
            $content
        );
        
        return $content;
    }
    
    // 删除目录的辅助函数
    private function deleteDirectory($dir) {
        if (!file_exists($dir)) {
            return true;
        }
        
        if (!is_dir($dir)) {
            return unlink($dir);
        }
        
        foreach (scandir($dir) as $item) {
            if ($item == '.' || $item == '..') {
                continue;
            }
            
            if (!$this->deleteDirectory($dir . '/' . $item)) {
                return false;
            }
        }
        
        return rmdir($dir);
    }
}

class AdminAuth {
    private $admin_username = 'admin';
    private $admin_password = 'password'; // 默认密码，将在初始化时被替换
    
    public function login($username, $password) {
        // 直接验证明文密码
        if ($username === $this->admin_username && $password === $this->admin_password) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $username; // 存储用户名到会话
            
            return true;
        }
        return false;
    }
    
    public function isLoggedIn() {
        return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
    }
    
    public function logout() {
        unset($_SESSION['admin_logged_in']);
    }
    
    // 验证当前密码而不改变登录状态
    public function verifyPassword($password) {
        return $password === $this->admin_password;
    }
}
?>