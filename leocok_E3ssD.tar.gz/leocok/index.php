<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/database.php';

$projectManager = new ProjectManager();
$projects = $projectManager->getAllProjects();

?>

<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/database.php';

$projectManager = new ProjectManager();
$projects = $projectManager->getAllProjects();

// 处理搜索
$search_query = $_GET['search'] ?? '';
if (!empty($search_query)) {
    $search_projects = [];
    foreach ($projects as $project) {
        if (stripos($project['title'], $search_query) !== false || 
            stripos($project['description'], $search_query) !== false) {
            $search_projects[] = $project;
        }
    }
    $projects = $search_projects;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- 樱花飘落效果 -->
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    <div class="sakura"></div>
    
    <header>
        <h1><?php echo SITE_NAME; ?></h1>
    </header>
    
    <nav style="display: none;">
        <a href="index.php">首页</a>
        <a href="admin/login.php">管理员登录</a>
    </nav>
    
    <main>
        <div class="search-container">
            <form method="GET" class="search-form">
                <input type="text" name="search" placeholder="搜索项目..." value="<?php echo htmlspecialchars($search_query); ?>">
                <button type="submit">搜索</button>
                <?php if (!empty($search_query)): ?>
                    <a href="index.php" class="clear-search">清除</a>
                <?php endif; ?>
            </form>
            <?php if (!empty($search_query)): ?>
                <p class="search-result">搜索 "<?php echo htmlspecialchars($search_query); ?>" 找到 <?php echo count($projects); ?> 个结果</p>
            <?php endif; ?>
        </div>
        
        <h2><?php echo empty($search_query) ? '项目列表' : '搜索结果'; ?></h2>
        <?php if (empty($projects)): ?>
            <p>暂无项目<?php echo !empty($search_query) ? '匹配您的搜索' : ''; ?></p>
        <?php else: ?>
            <div class="projects-grid">
                <?php foreach ($projects as $project): ?>
                    <a href="x/<?php echo $project['id']; ?>.html" class="project-card-link">
                    <div class="project-card">
                        <h3><?php echo htmlspecialchars($project['title']); ?></h3>
                        <p><?php echo htmlspecialchars(substr($project['description'], 0, 100)); ?>...</p>
                        <small>发布时间: <?php echo date('Y-m-d H:i', strtotime($project['created_at'])); ?></small>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>
    
    <!-- 右下角浮动导航按钮 -->
    <div class="floating-nav">
        <button class="nav-toggle" id="navToggle">
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
            <span class="nav-icon"></span>
        </button>
        <div class="nav-menu" id="navMenu">
            <a href="index.php" class="nav-link">首页</a>
            <a href="admin/login.php" class="nav-link">管理员登录</a>
        </div>
    </div>

    <footer>
        <?php
        // 从配置文件获取备案信息
        $beian_info = '';
        $beian_file = 'includes/beian.php';
        if (file_exists($beian_file)) {
            require_once $beian_file;
            $beian_num = defined('BEIAN_NUMBER') ? BEIAN_NUMBER : '';
            $beian_url = defined('BEIAN_URL') ? BEIAN_URL : '';
            $author_show = defined('SHOW_AUTHOR') ? SHOW_AUTHOR : true;
            $user_show = defined('SHOW_USER') ? SHOW_USER : true;
            $user_name = defined('USER_NAME') ? USER_NAME : '';
        } else {
            $beian_num = '';
            $beian_url = '';
            $author_show = true;
            $user_show = true;
            $user_name = '';
        }
        
        echo '<p>&copy; 2025 ' . SITE_NAME . '. ';
        
        if (!empty($beian_num)) {
            echo '备案号' . $beian_num;
            if (!empty($beian_url)) {
                echo ' (<a href="http://' . $beian_url . '" target="_blank">备案网址</a>)';
            }
            echo ' ';
        }
        
        if ($author_show) {
            echo '作者:赤源谷雨 ';
        }
        
        if ($user_show && !empty($user_name)) {
            echo '使用者:' . $user_name . ' ';
        }
        
        echo '</p>';
        ?>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const navToggle = document.getElementById('navToggle');
            const navMenu = document.getElementById('navMenu');
            
            navToggle.addEventListener('click', function() {
                navMenu.classList.toggle('show');
            });
            
            // 点击菜单项后关闭菜单
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', () => {
                    navMenu.classList.remove('show');
                });
            });
        });
    </script>
</body>
</html>